package com.faruque.player

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.firebase.analytics.FirebaseAnalytics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class VideoItem(val id: Long, val title: String, val uri: Uri, val durationMs: Long)

/** ব্যবহারকারী গণনার জন্য Firebase ইভেন্ট। google-services.json না থাকলে চুপচাপ কিছু করবে না। */
object Stats {
    fun log(context: Context, event: String) {
        try {
            FirebaseAnalytics.getInstance(context).logEvent(event, null)
        } catch (_: Throwable) {
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Stats.log(this, "app_launch")
        setContent {
            MaterialTheme {
                App()
            }
        }
    }
}

@Composable
fun App() {
    val context = LocalContext.current
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_VIDEO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
    }
    var videos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var current by remember { mutableStateOf<VideoItem?>(null) }

    LaunchedEffect(granted) {
        if (granted) {
            videos = withContext(Dispatchers.IO) { loadVideos(context) }
        } else {
            launcher.launch(permission)
        }
    }

    val playing = current
    if (playing != null) {
        PlayerScreen(video = playing, onBack = { current = null })
    } else {
        VideoList(
            videos = videos,
            granted = granted,
            onPick = { current = it },
            onAskPermission = { launcher.launch(permission) }
        )
    }
}

@Composable
fun VideoList(
    videos: List<VideoItem>,
    granted: Boolean,
    onPick: (VideoItem) -> Unit,
    onAskPermission: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            text = "My Player",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(16.dp)
        )
        if (!granted) {
            Text(
                text = "ভিডিও দেখাতে অনুমতি দরকার। এখানে চাপ দিন।",
                modifier = Modifier.padding(16.dp).clickable { onAskPermission() }
            )
        } else if (videos.isEmpty()) {
            Text(text = "কোনো ভিডিও পাওয়া যায়নি।", modifier = Modifier.padding(16.dp))
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(videos, key = { it.id }) { video ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPick(video) }
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Text(text = video.title, style = MaterialTheme.typography.bodyLarge, maxLines = 2)
                        Text(
                            text = formatDuration(video.durationMs),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(video: VideoItem, onBack: () -> Unit) {
    val context = LocalContext.current
    val exo = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.uri))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(Unit) {
        Stats.log(context, "video_play")
        onDispose { exo.release() }
    }
    BackHandler { onBack() }
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply { player = exo } },
        modifier = Modifier.fillMaxSize()
    )
}

fun loadVideos(context: Context): List<VideoItem> {
    val list = mutableListOf<VideoItem>()
    val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.DURATION
    )
    context.contentResolver.query(
        collection, projection, null, null,
        "${MediaStore.Video.Media.DATE_ADDED} DESC"
    )?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
        val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
        val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
        while (cursor.moveToNext()) {
            val id = cursor.getLong(idCol)
            list.add(
                VideoItem(
                    id = id,
                    title = cursor.getString(nameCol) ?: "Video",
                    uri = ContentUris.withAppendedId(collection, id),
                    durationMs = cursor.getLong(durCol)
                )
            )
        }
    }
    return list
}

fun formatDuration(ms: Long): String {
    val totalSec = ms / 1000
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
