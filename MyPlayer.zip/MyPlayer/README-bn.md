# My Player — ধাপে ধাপে চালানোর নির্দেশ

## ১. Android Studio নামান
https://developer.android.com/studio থেকে নামিয়ে ইনস্টল করুন (Windows/Mac দুটোতেই চলে)।

## ২. প্রজেক্ট খুলুন
1. এই zip ফাইল আনজিপ করুন।
2. Android Studio → Open → `MyPlayer` ফোল্ডার বেছে নিন।
3. নিচে "Sync" বা "Gradle" কাজ শেষ হওয়া পর্যন্ত অপেক্ষা করুন (প্রথমবার ১০–১৫ মিনিট লাগতে পারে, ইন্টারনেট লাগবে)।
4. কোনো লাল এরর এলে স্ক্রিনশট বা টেক্সট কপি করে আমাকে পাঠান।

## ৩. ফোনে চালান
1. ফোনে Settings → About phone → Build number-এ ৭ বার চাপুন (Developer mode)।
2. Developer options → USB debugging চালু করুন।
3. USB দিয়ে ফোন লাগান, Android Studio-র উপরে ফোন বেছে ▶ (Run) চাপুন।

## ৪. ব্যবহারকারী গোনা (Firebase)
1. https://console.firebase.google.com → Add project।
2. Project-এ Android অ্যাপ যোগ করুন, package name দিন: `com.faruque.player`
3. `google-services.json` ফাইল নামিয়ে `MyPlayer/app/` ফোল্ডারে রাখুন।
4. আবার Sync করে অ্যাপ চালান। Firebase Console → Analytics → Dashboard-এ সংখ্যা দেখা যাবে (প্রথমবার আসতে ২৪ ঘণ্টা পর্যন্ত লাগতে পারে)।
